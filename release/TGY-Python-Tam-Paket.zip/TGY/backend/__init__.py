"""TGY kalıcı uygulama sunucusu."""
